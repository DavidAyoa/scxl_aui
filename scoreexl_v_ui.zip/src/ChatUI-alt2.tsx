import { useState } from "react";
import TextareaAutosize from "react-textarea-autosize";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "./components/ui/tooltip";
import clsx from "clsx";
import "./App.css";
import AudioLines from "./icons/AudioLines";
import Conversations from "./components/ChatUI/Conversations";
import UserAudio from "./components/ChatUI/UserAudio";
import { useSmallWebRTC } from "./hooks/useSmallWebRTC-alt";
import {
  PipecatClientAudio,
  PipecatClientProvider,
} from "@pipecat-ai/client-react";
// import BotAudioPanel from "./components/ChatUI/BotAudioPanel";

const TEXTAREA_CONFIG = {
  MIN_ROWS: 1,
  MAX_ROWS: 10,
} as const;

const ChatUI2: React.FC = () => {
  const [isAtMaxHeight, setIsAtMaxHeight] = useState(false);

  // Initialize WebRTC hook
  const {
    client,
    isConnected,
    isClientReady,
    participantId,
    error,
    connect,
    disconnect,
  } = useSmallWebRTC({
    enableMic: true,
    connectParams: {
      connectionUrl: "http://localhost:7860/api/offer",
      // requestData: {
      //   system_prompt: "Your purpose in this conversation is to only talk about butter and nothing else."
      // }
    },
    onParticipantJoined: (participant) => {
      console.log("Participant joined:", participant);
    },
    onTrackStarted: (track, participant) => {
      console.log("Track started:", {
        kind: track.kind,
        enabled: track.enabled,
        muted: track.muted,
        readyState: track.readyState,
        participant: participant,
      });
    },
  });

  const handleHeightChange = (height: number) => {
    setIsAtMaxHeight(height >= 240);
  };

  const handleConnect = async () => {
    try {
      await connect();
    } catch (err) {
      console.error("Failed to connect:", err);
    }
  };

  const handleDisconnect = async () => {
    try {
      await disconnect();
    } catch (err) {
      console.error("Failed to disconnect:", err);
    }
  };

  // Show connection interface when not connected
  if (!isConnected || !client) {
    return (
      <div className="scxl:w-full scxl:h-screen scxl:p-5 scxl:font-poppins scxl:flex scxl:justify-center scxl:items-center">
        <div className="scxl:flex scxl:flex-col scxl:items-center scxl:gap-6">
          <div className="scxl:text-center scxl:space-y-2">
            <h1 className="scxl:text-2xl scxl:font-bold scxl:text-gray-900">
              Voice Chat
            </h1>
            <p className="scxl:text-gray-600">
              Connect to start your voice conversation
            </p>
          </div>

          {error && (
            <div className="scxl:bg-red-50 scxl:border scxl:border-red-200 scxl:rounded-lg scxl:p-4">
              <p className="scxl:text-red-800 scxl:text-sm">{error}</p>
            </div>
          )}

          <button
            onClick={handleConnect}
            disabled={!isClientReady}
            className={clsx(
              "scxl:px-6 scxl:py-3 scxl:rounded-lg scxl:font-medium scxl:transition-all scxl:duration-200",
              isClientReady
                ? "scxl:bg-indigo-500 scxl:text-white hover:scxl:bg-indigo-600 scxl:cursor-pointer"
                : "scxl:bg-gray-300 scxl:text-gray-500 scxl:cursor-not-allowed"
            )}
          >
            {isClientReady ? "Connect" : "Initializing..."}
          </button>

          {participantId && (
            <p className="scxl:text-sm scxl:text-gray-500">
              Participant ID: {participantId}
            </p>
          )}
        </div>
      </div>
    );
  }

  // Show chat interface when connected
  return (
    <PipecatClientProvider client={client}>
      <div className="scxl:w-full scxl:h-screen scxl:p-5 scxl:font-poppins scxl:flex scxl:justify-center scxl:items-center">
        <div className="scxl:w-full scxl:h-full scxl:flex scxl:flex-1 scxl:flex-col scxl:justify-center scxl:items-center">
          <div className="scxl:sm:min-w-md scxl:sm:w-3/4 scxl:sm:max-w-4xl scxl:w-full scxl:h-full scxl:flex scxl:flex-col scxl:justify-center scxl:items-center">
            <Conversations />
            <div className="scxl:w-full scxl:flex scxl:flex-col scxl:border-[1.5px] scxl:border-indigo-500 scxl:rounded-2xl">
              <TextareaAutosize
                name="user_input"
                title="User input"
                placeholder="Ask anything..."
                minRows={TEXTAREA_CONFIG.MIN_ROWS}
                maxRows={TEXTAREA_CONFIG.MAX_ROWS}
                onHeightChange={handleHeightChange}
                className={clsx(
                  "scxl:font-medium scxl:input-scxl scxl:outline-none scxl:border-none scxl:w-full scxl:p-4 scxl:text-sm scxl:resize-none scxl:transition-all scxl:duration-200 scxl:ease-in-out",
                  isAtMaxHeight && "scxl:overflow-y-auto"
                )}
              />
              <div className="scxl:w-full scxl:flex scxl:items-center scxl:justify-between scxl:px-2 scxl:h-fit">
                <div className="scxl:flex scxl:flex-row scxl:items-center scxl:p-2">
                  <span className="scxl:relative scxl:flex scxl:size-3">
                    <span className="scxl:absolute scxl:inline-flex scxl:h-full scxl:w-full scxl:animate-ping scxl:rounded-full scxl:bg-indigo-500 scxl:opacity-75"></span>
                    <span className="scxl:relative scxl:inline-flex scxl:size-3 scxl:rounded-full scxl:bg-indigo-400"></span>
                  </span>
                  <div className="scxl:ml-2 scxl:text-xs scxl:font-medium">
                    Connected
                    {participantId && (
                      <span className="scxl:ml-1 scxl:text-gray-500">
                        ({participantId.slice(0, 8)}...)
                      </span>
                    )}
                  </div>
                </div>
                <div className="scxl:flex scxl:items-center scxl:gap-2">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        title="Audio"
                        className="scxl:flex scxl:items-center scxl:justify-center scxl:gap-1.5 scxl:font-medium scxl:p-2 scxl:text-sm scxl:cursor-pointer hover:scxl:-translate-y-0.5 scxl:transition-all scxl:duration-200 scxl:ease-in-out"
                        type="button"
                      >
                        <span className="scxl:text-xs scxl:text-indigo-500">
                          Switch to voice
                        </span>{" "}
                        <AudioLines />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent sideOffset={5}>
                      Click to switch to voice, you can switch back to text at
                      any time
                    </TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={handleDisconnect}
                        className="scxl:text-xs scxl:bg-red-500 scxl:text-white scxl:hover:bg-red-700 scxl:p-2 scxl:rounded-full scxl:transition-colors"
                        type="button"
                      >
                        Disconnect
                      </button>
                    </TooltipTrigger>
                    <TooltipContent sideOffset={5}>
                      Disconnect from voice chat
                    </TooltipContent>
                  </Tooltip>
                </div>
              </div>
              {/* <BotAudioPanel /> */}
            </div>
            <UserAudio />
          </div>
        </div>
        <PipecatClientAudio />
      </div>
    </PipecatClientProvider>
  );
};

export default ChatUI2;
