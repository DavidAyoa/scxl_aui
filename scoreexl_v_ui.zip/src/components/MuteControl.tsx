function MuteControl() {
    return (
        <div>
            
        </div>
    )
}

export default MuteControl