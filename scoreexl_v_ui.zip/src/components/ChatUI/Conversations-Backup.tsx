import { useEffect, useRef } from "react";
import { type LenisRef, ReactLenis } from "lenis/react";
import { cancelFrame, frame } from "motion/react";
import ResponseParser from "../ResponseParser";

interface FrameData {
  delta: number;
  timestamp: number;
  isProcessing: boolean;
}

const sample_raw_response = `**One Piece: Enies Lobby Arc Summary**

In the Enies Lobby arc, the Straw Hat Pirates stage a daring assault on the World Government’s judicial island to rescue their crewmate, Nico Robin, who has surrendered herself to protect them. They team up with the Franky Family and Galley-La workers to storm the island via the Sea Train. The crew confronts CP9, the secret government assassination unit, each member facing a powerful opponent.

Luffy unveils his new Gear Second and Gear Third forms, ultimately defeating Rob Lucci in a brutal fight. Robin finally admits her desire to live, moving the crew to risk everything for her freedom. Usopp, still masked as Sogeking, plays a crucial role in burning the World Government's flag and destroying the Sea Train bridge.

The Buster Call—a devastating military bombardment—is triggered, but the crew escapes with Robin thanks to teamwork and the unexpected arrival of the Going Merry. However, the ship sustains fatal damage and receives an emotional Viking funeral. Franky joins the crew afterward, and the arc concludes with the introduction of their new ship, the Thousand Sunny. The Enies Lobby arc is pivotal, deepening character bonds and escalating the Straw Hats’ defiance against the World Government.
`;

function Conversations() {
  const lenisRef = useRef<LenisRef | null>(null);
  useEffect(() => {
    function update(data: FrameData) {
      if (lenisRef.current?.lenis) {
        lenisRef.current.lenis.raf(data.timestamp);
      }
    }

    frame.update(update, true);
    return () => {
      cancelFrame(update);
    };
  }, []);

  return (
    <ReactLenis
      options={{
        autoRaf: false,
        smoothWheel: true,
        wheelMultiplier: 2,
        touchMultiplier: 2,
      }}
      className="scxl:flex-1 scxl:sm:w-3/4 scxl:sm:max-w-4xl chat-scxl scxl:w-full! scxl:sm:p-5 scxl:p-2 scxl:overflow-y-auto"
      ref={lenisRef}
    >
      {/* <div className="flex-1 sm:w-3/4 sm:max-w-4xl w-full sm:p-5 p-2 overflow-y-auto"> */}
      <div className="scxl:w-full scxl:h-full scxl:flex scxl:flex-col">
        <div className="scxl:flex scxl:flex-row scxl:w-full scxl:justify-end">
          <div className="scxl:max-w-3/4 scxl:text-sm scxl:bg-indigo-500 scxl:p-2 scxl:rounded-tr-xl scxl:rounded-tl-xl scxl:rounded-bl-xl scxl:m-2">
            <p className="scxl:text-white">
              give me a summary of one piece enies lobby, max 200 words
            </p>
          </div>
        </div>
        <div className="scxl:flex scxl:flex-row scxl:w-full">
          <div className="scxl:w-full scxl:text-sm scxl:p-2 scxl:m-2">
            <ResponseParser rawContent={sample_raw_response} />
          </div>
        </div>
      </div>
      {/* </div> */}
    </ReactLenis>
  );
}

export default Conversations;
