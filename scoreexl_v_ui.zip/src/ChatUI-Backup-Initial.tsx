import { useState, useEffect } from "react";
import TextareaAutosize from "react-textarea-autosize";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "./components/ui/tooltip";
import clsx from "clsx";
import "./App.css";
import AudioLines from "./icons/AudioLines";
import {
  type ConnectionEndpoint,
  PipecatClient,
  type PipecatClientOptions,
  Transport,
  type TransportConnectionParams,
} from "@pipecat-ai/client-js";
import { SmallWebRTCTransport } from "@pipecat-ai/small-webrtc-transport";
import {
  PipecatClientAudio,
  PipecatClientProvider,
} from "@pipecat-ai/client-react";
import Conversations from "./components/ChatUI/Conversations";
import SvgPathLoader from "./components/ChatUI/SvgPathLoader";
import ConnectButton from "./components/ChatUI/ConnectButton";

const TEXTAREA_CONFIG = {
  MIN_ROWS: 1,
  MAX_ROWS: 10,
} as const;

export interface ScoreexlChatUIProps {
  /**
   * Sets the audio codec. Only applicable for SmallWebRTC transport.
   * Defaults to "default" which uses the browser's default codec.
   */
  audioCodec?: string;
  /**
   * Options for configuring the RTVI client.
   */
  clientOptions?: Partial<PipecatClientOptions>;
  /**
   * Parameters for connecting to the transport.
   */
  connectParams?: TransportConnectionParams | ConnectionEndpoint;
  /**
   * Disables audio output for the bot. The bot may still send audio, but it won't be played.
   */
  noAudioOutput?: boolean;
  /**
   * Disables audio visualization for the bot.
   * The bot may still send audio, but it won't be visualized.
   */
  noBotAudio?: boolean;
  /**
   * Disables the conversation panel.
   * The bot may still send messages, but they won't be displayed.
   */
  noConversation?: boolean;
  /**
   * Disables the session info panel.
   */
  noSessionInfo?: boolean;
  /**
   * Disables the status info panel.
   */
  noStatusInfo?: boolean;
  /**
   * Disables user audio input entirely.
   */
  noUserAudio?: boolean;
  /**
   * Title displayed in the header.
   * Defaults to "Pipecat Playground".
   */
  title?: string;
  /**
   * Type of transport to use for the RTVI client.
   * - "smallwebrtc" for SmallWebRTC Transport
   * Defaults to "smallwebrtc".
   */
  transportType?: "smallwebrtc";
}

const defaultClientOptions: Partial<PipecatClientOptions> = {};

const App: React.FC<ScoreexlChatUIProps> = ({
  audioCodec = "default",
  clientOptions = defaultClientOptions,
  connectParams,
  noAudioOutput = false,
  noUserAudio = false,
  transportType = "smallwebrtc",
}) => {
  const [isAtMaxHeight, setIsAtMaxHeight] = useState(false);
  const [sessionId, setSessionId] = useState("");
  const [participantId, setParticipantId] = useState("");
  const [client, setClient] = useState<PipecatClient | null>(null);
  const [isClientReady, setIsClientReady] = useState(false);
  const [chatInitialized, setChatInitialized] = useState(false);

  useEffect(
    function initClient() {
      // Only run on client side
      if (typeof window === "undefined") return;

      const transport = new SmallWebRTCTransport({
        iceServers: [{urls: "stun:stun.l.google.com:19302"}],
      });
      
      const pcClient = new PipecatClient({
        enableCam: false,
        enableMic: !noUserAudio,
        ...clientOptions,
        transport: (clientOptions?.transport as Transport) ?? transport,
        callbacks: {
          onParticipantJoined: (participant) => {
            setParticipantId(participant.id || "");
            clientOptions?.callbacks?.onParticipantJoined?.(participant);
          },
          onTrackStarted(track, participant) {
            if (participant?.id && participant.local)
              setParticipantId(participant.id);
            clientOptions?.callbacks?.onTrackStarted?.(track, participant);
          },
        },
      });
      pcClient.initDevices();
      setClient(pcClient);
      setIsClientReady(true);
      return () => {
        /**
         * Disconnect client when component unmounts or options change.
         */
        pcClient.disconnect();
      };
    },
    [clientOptions, noUserAudio, transportType]
  );

  useEffect(
    function updateSmallWebRTCCodecs() {
      if (!client || transportType !== "smallwebrtc") return;
      const transport = client.transport as SmallWebRTCTransport;
      if (audioCodec) {
        transport.setAudioCodec(audioCodec);
      }
    },
    [audioCodec, client, transportType]
  );

  const handleConnect = async () => {
    if (!client) return;
    try {
      console.log('🚀 Starting connection...');
      await client.connect(connectParams);
      setChatInitialized(true);
      console.log('🎉 Connected to Pipecat!');
    } catch (error) {
      console.error('❌ Failed to connect:', error);
      await client.disconnect();
    }
  };

  const handleDisconnect = async () => {
    if (!client) return;
    try {
      console.log('🔌 Disconnecting...');
      await client.disconnect();
      setChatInitialized(false);
      console.log('✅ Disconnected successfully');
    } catch (error) {
      console.error('❌ Failed to disconnect:', error);
    }
  };

  const handleHeightChange = (height: number) => {
    setIsAtMaxHeight(height >= 240);
  };

  if (client === null) {
    return <>Client is null</>;
  }

  // Return loading state until client is ready (prevents hydration mismatch)
  if (!isClientReady || !client) {
    return (
      <div className="scxl:flex scxl:items-center scxl:justify-center scxl:h-full scxl:w-full">
        <SvgPathLoader />
      </div>
    );
  }

  return (
    <PipecatClientProvider client={client}>
      {!chatInitialized ? (
        <div className="scxl:w-full scxl:h-screen scxl:p-5 scxl:font-poppins scxl:flex scxl:justify-center scxl:items-center">
          <ConnectButton
            onConnect={handleConnect}
            onDisconnect={handleDisconnect}
          />
        </div>
      ) : (
        <div className="scxl:w-full scxl:h-screen scxl:p-5 scxl:font-poppins scxl:flex scxl:justify-center scxl:items-center">
          <div className="scxl:w-full scxl:h-full scxl:flex scxl:flex-1 scxl:flex-col scxl:justify-center scxl:items-center">
            <div className="scxl:sm:min-w-md scxl:sm:w-3/4 scxl:sm:max-w-4xl scxl:w-full scxl:h-full scxl:flex scxl:flex-col scxl:justify-center scxl:items-center">
              <Conversations />
              <div className="scxl:w-full scxl:flex scxl:flex-col scxl:border-[1.5px] scxl:border-indigo-500 scxl:rounded-2xl">
                <TextareaAutosize
                  name="user_input"
                  title="User input"
                  placeholder="Ask anything..."
                  minRows={TEXTAREA_CONFIG.MIN_ROWS}
                  maxRows={TEXTAREA_CONFIG.MAX_ROWS}
                  onHeightChange={handleHeightChange}
                  className={clsx(
                    "scxl:font-medium scxl:input-scxl scxl:outline-none scxl:border-none scxl:w-full scxl:p-4 scxl:text-sm scxl:resize-none scxl:transition-all scxl:duration-200 scxl:ease-in-out",
                    isAtMaxHeight && "scxl:overflow-y-auto"
                  )}
                />
                <div className="scxl:w-full scxl:flex scxl:items-center scxl:justify-between scxl:px-2 scxl:h-fit">
                  <div className="scxl:flex scxl:flex-row scxl:items-center scxl:p-2">
                    <span className="scxl:relative scxl:flex scxl:size-3">
                      <span className="scxl:absolute scxl:inline-flex scxl:h-full scxl:w-full scxl:animate-ping scxl:rounded-full scxl:bg-indigo-500 scxl:opacity-75"></span>
                      <span className="scxl:relative scxl:inline-flex scxl:size-3 scxl:rounded-full scxl:bg-indigo-400"></span>
                    </span>
                    <div className="scxl:ml-2 scxl:text-xs scxl:font-medium">
                      Connected
                    </div>
                  </div>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        title="Audio"
                        className="scxl:flex scxl:items-center scxl:justify-center scxl:gap-1.5 scxl:font-medium scxl:p-2 scxl:text-sm scxl:cursor-pointer hover:scxl:-translate-y-0.5 scxl:transition-all scxl:duration-200 scxl:ease-in-out"
                        type="submit"
                      >
                        <span className="scxl:text-xs scxl:text-indigo-500">
                          Switch to voice
                        </span>{" "}
                        <AudioLines />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent sideOffset={5}>
                      click to switch to voice, you can switch back to text at
                      any time
                    </TooltipContent>
                  </Tooltip>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      {!noAudioOutput && <PipecatClientAudio />}
    </PipecatClientProvider>
  );
};

export default App;
