import { useCallback, useState, useMemo, useEffect } from "react";
import TextareaAutosize from "react-textarea-autosize";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "./components/ui/tooltip";
import clsx from "clsx";
import "./App.css";
import AudioLines from "./icons/AudioLines";
import { PipecatClient, RTVIEvent } from "@pipecat-ai/client-js";
import {
  usePipecatClient,
  useRTVIClientEvent,
  usePipecatClientTransportState,
  PipecatClientProvider,
  PipecatClientAudio,
} from "@pipecat-ai/client-react";
import Conversations from "./components/ChatUI/Conversations";
import ConnectButton from "./components/ChatUI/ConnectButton";
import { SmallWebRTCTransport } from "@pipecat-ai/small-webrtc-transport";
import UserAudio from "./components/ChatUI/UserAudio";

const TEXTAREA_CONFIG = {
  MIN_ROWS: 1,
  MAX_ROWS: 10,
} as const;

// Inner component that uses the client from context
function ChatUIInner() {
  const client = usePipecatClient();
  const transportState = usePipecatClientTransportState();

  const [isAtMaxHeight, setIsAtMaxHeight] = useState(false);
  const [chatInitialized, setChatInitialized] = useState(false);

  // Connection state - use transport state
  const isConnected =
    transportState === "connected" || transportState === "ready";
  //   const isReady = transportState === 'ready';

  // Handle connection events
  useRTVIClientEvent(
    RTVIEvent.Connected,
    useCallback(() => {
      console.log("Connected to WebSocket");
      setChatInitialized(true);
    }, [])
  );

  useRTVIClientEvent(
    RTVIEvent.Disconnected,
    useCallback(() => {
      console.log("Disconnected from WebSocket");
      setChatInitialized(false);
    }, [])
  );

  useRTVIClientEvent(
    RTVIEvent.TransportStateChanged,
    useCallback((state: any) => {
      console.log("Transport state changed to:", state);
    }, [])
  );

  useRTVIClientEvent(
    RTVIEvent.BotReady,
    useCallback((data: any) => {
      console.log(`Bot ready: ${JSON.stringify(data)}`);
    }, [])
  );

  useRTVIClientEvent(
    RTVIEvent.Error,
    useCallback((error: any) => {
      console.error("RTVI error:", error);
    }, [])
  );

  const handleConnect = async () => {
    if (!client) return;

    try {
      console.log("🚀 Starting connection...");

      // Use proper connection endpoint according to docs
      const connectParams = {
        connectionUrl: "http://localhost:7860/api/offer",
      };

      await client.connect(connectParams);

      console.log("🎉 Connected to Pipecat!");
    } catch (error) {
      console.error("❌ Failed to connect:", error);
      try {
        await client.disconnect();
      } catch (disconnectError) {
        console.error(
          "Error disconnecting after failed connect:",
          disconnectError
        );
      }
    }
  };

  const handleDisconnect = async () => {
    if (!client) return;

    try {
      console.log("🔌 Disconnecting...");
      await client.disconnect();
      console.log("✅ Disconnected successfully");
    } catch (error) {
      console.error("❌ Failed to disconnect:", error);
    }
  };

  const handleHeightChange = (height: number) => {
    setIsAtMaxHeight(height >= 240);
  };

  useEffect(
    function updateSmallWebRTCCodecs() {
      if (!client) return;
      const transport = client.transport as SmallWebRTCTransport;
      transport.setAudioCodec("default");
    },
    [client],
  );

  return (
    <>
      {!chatInitialized || !isConnected ? (
        <div className="scxl:w-full scxl:h-screen scxl:p-5 scxl:font-poppins scxl:flex scxl:justify-center scxl:items-center">
          <ConnectButton
            onConnect={handleConnect}
            onDisconnect={handleDisconnect}
          />
        </div>
      ) : (
        <div className="scxl:w-full scxl:h-screen scxl:p-5 scxl:font-poppins scxl:flex scxl:justify-center scxl:items-center">
          <div className="scxl:w-full scxl:h-full scxl:flex scxl:flex-1 scxl:flex-col scxl:justify-center scxl:items-center">
            <div className="scxl:sm:min-w-md scxl:sm:w-3/4 scxl:sm:max-w-4xl scxl:w-full scxl:h-full scxl:flex scxl:flex-col scxl:justify-center scxl:items-center">
              <Conversations />
              <div className="scxl:w-full scxl:flex scxl:flex-col scxl:border-[1.5px] scxl:border-indigo-500 scxl:rounded-2xl">
                <TextareaAutosize
                  name="user_input"
                  title="User input"
                  placeholder="Ask anything..."
                  minRows={TEXTAREA_CONFIG.MIN_ROWS}
                  maxRows={TEXTAREA_CONFIG.MAX_ROWS}
                  onHeightChange={handleHeightChange}
                  className={clsx(
                    "scxl:font-medium scxl:input-scxl scxl:outline-none scxl:border-none scxl:w-full scxl:p-4 scxl:text-sm scxl:resize-none scxl:transition-all scxl:duration-200 scxl:ease-in-out",
                    isAtMaxHeight && "scxl:overflow-y-auto"
                  )}
                />
                <div className="scxl:w-full scxl:flex scxl:items-center scxl:justify-between scxl:px-2 scxl:h-fit">
                  <div className="scxl:flex scxl:flex-row scxl:items-center scxl:p-2">
                    <span className="scxl:relative scxl:flex scxl:size-3">
                      <span
                        className={`scxl:absolute scxl:inline-flex scxl:h-full scxl:w-full scxl:animate-ping scxl:rounded-full scxl:opacity-75 ${
                          isConnected ? "scxl:bg-indigo-500" : "scxl:bg-red-500"
                        }`}
                      ></span>
                      <span
                        className={`scxl:relative scxl:inline-flex scxl:size-3 scxl:rounded-full ${
                          isConnected ? "scxl:bg-indigo-400" : "scxl:bg-red-400"
                        }`}
                      ></span>
                    </span>
                    <div className="scxl:ml-2 scxl:text-xs scxl:font-medium">
                      {isConnected
                        ? "Connected"
                        : transportState === "connecting"
                        ? "Connecting"
                        : "Disconnected"}
                    </div>
                  </div>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        title="Audio"
                        className="scxl:flex scxl:items-center scxl:justify-center scxl:gap-1.5 scxl:font-medium scxl:p-2 scxl:text-sm scxl:cursor-pointer hover:scxl:-translate-y-0.5 scxl:transition-all scxl:duration-200 scxl:ease-in-out"
                        type="submit"
                      >
                        <span className="scxl:text-xs scxl:text-indigo-500">
                          Switch to voice
                        </span>{" "}
                        <AudioLines />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent sideOffset={5}>
                      click to switch to voice, you can switch back to text at
                      any time
                    </TooltipContent>
                  </Tooltip>
                </div>
              </div>
              {/* <UserAudio /> */}
            </div>
          </div>
          <PipecatClientAudio />
        </div>
      )}
    </>
  );
}

// Main ChatUI component with provider
function ChatUI() {
  const pcClient = useMemo(() => {
    const transport = new SmallWebRTCTransport({
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
    });

    return new PipecatClient({
      transport,
      enableCam: false,
      enableMic: true,
      callbacks: {
        onConnected: () => console.log("Connected to bot"),
        onDisconnected: () => console.log("Disconnected from bot"),
        onError: (error: any) => console.error("RTVI error:", error),
      },
    });
  }, []);

  return (
    <PipecatClientProvider client={pcClient}>
      <ChatUIInner />
    </PipecatClientProvider>
  );
}

export default ChatUI;
