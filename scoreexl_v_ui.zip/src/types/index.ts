export interface ResponseParserProps {
  rawContent: string
  className?: string
  typewriterEffect?: boolean
  timeStamp?: string
  typewriterSpeed?: number
  disableTypewriter?: boolean
}
