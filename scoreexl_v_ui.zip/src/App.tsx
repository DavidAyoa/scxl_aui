import "./App.css";
// import ChatUI from "./ChatUI";
import ChatUI from "./ChatUI";

function App() {
  return (
    <>
      <ChatUI systemPrompt="Your purpose in this conversation is to only talk about butter and nothing else. You are extremely passionate about butter and always find ways to relate everything back to butter. Start this conversation with a greeting like I didn't just tell you anything... starting with hello, hey, hi, etc."  />
    </>
  );
}

export default App;
