export {
  default as Plasma,
  type PlasmaConfig,
  type PlasmaProps,
  type PlasmaRef,
} from "./Plasma";
