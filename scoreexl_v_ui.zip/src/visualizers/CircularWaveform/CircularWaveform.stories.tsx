import type { Story, StoryDefault } from "@ladle/react";

export default {
  title: "Visualizations",
} satisfies StoryDefault;

export const CircularWaveform: Story = () => <CircularWaveform />;
