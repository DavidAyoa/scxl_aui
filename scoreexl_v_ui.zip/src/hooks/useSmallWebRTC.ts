import { useEffect, useState, useCallback, useMemo } from "react";
import {
  type ConnectionEndpoint,
  PipecatClient,
  type PipecatClientOptions,
  Transport,
  type TransportConnectionParams,
} from "@pipecat-ai/client-js";
import {
  SmallWebRTCTransport,
  type SmallWebRTCTransportConstructorOptions,
} from "@pipecat-ai/small-webrtc-transport";

export interface ConsoleTemplateProps {
  /**
   * Sets the audio codec. Only applicable for SmallWebRTC transport.
   * Defaults to "default" which uses the browser's default codec.
   */
  audioCodec?: string;
  /**
   * Options for configuring the RTVI client.
   */
  clientOptions?: Partial<PipecatClientOptions>;
  /**
   * Parameters for connecting to the transport.
   */
  connectParams?: TransportConnectionParams | ConnectionEndpoint;
  /**
   * Disables user audio input entirely.
   */
  noUserAudio?: boolean;
  /**
   * System prompt to be used for the AI assistant.
   * This defines the behavior and personality of the AI.
   */
  systemPrompt?: string;
  /**
   * Type of transport to use for the RTVI client.
   * - "smallwebrtc" for SmallWebRTC Transport
   * Defaults to "smallwebrtc".
   */
  transportType?: "smallwebrtc";
}

interface UseSmallWebRTCReturn {
  client: PipecatClient | null;
  isClientReady: boolean;
  isConnected: boolean;
  participantId: string;
  handleConnect: () => Promise<void>;
  handleDisconnect: () => Promise<void>;
}

const defaultClientOptions: Partial<PipecatClientOptions> = {};

export const useSmallWebRTC = ({
  audioCodec = "default",
  clientOptions = defaultClientOptions,
  connectParams,
  noUserAudio = false,
  systemPrompt = "You are a helpful AI assistant.",
  transportType = "smallwebrtc",
}: ConsoleTemplateProps): UseSmallWebRTCReturn => {
  const [participantId, setParticipantId] = useState("");
  const [client, setClient] = useState<PipecatClient | null>(null);
  const [isClientReady, setIsClientReady] = useState(false);
  const [isConnected, setIsConnected] = useState(false);

  const onParticipantJoined = useCallback((participant: any) => {
    setParticipantId(participant.id || "");
    clientOptions?.callbacks?.onParticipantJoined?.(participant);
  }, [clientOptions?.callbacks?.onParticipantJoined]);

  const onTrackStarted = useCallback((track: any, participant: any) => {
    if (participant?.id && participant.local) {
      setParticipantId(participant.id);
    }
    clientOptions?.callbacks?.onTrackStarted?.(track, participant);
  }, [clientOptions?.callbacks?.onTrackStarted]);

  const onError = useCallback((error: any) => {
    clientOptions?.callbacks?.onError?.(error);
  }, [clientOptions?.callbacks?.onError]);

  const onBotReady = useCallback(() => {
    clientOptions?.callbacks?.onBotReady?.({
      version: "0.1.0",
    });
  }, [clientOptions?.callbacks?.onBotReady]);

  const onUserStartedSpeaking = useCallback(() => {
    clientOptions?.callbacks?.onUserStartedSpeaking?.();
  }, [clientOptions?.callbacks?.onUserStartedSpeaking]);

  const onUserStoppedSpeaking = useCallback(() => {
    clientOptions?.callbacks?.onUserStoppedSpeaking?.();
  }, [clientOptions?.callbacks?.onUserStoppedSpeaking]);

  const onBotStartedSpeaking = useCallback(() => {
    clientOptions?.callbacks?.onBotStartedSpeaking?.();
  }, [clientOptions?.callbacks?.onBotStartedSpeaking]);

  const onBotStoppedSpeaking = useCallback(() => {
    clientOptions?.callbacks?.onBotStoppedSpeaking?.();
  }, [clientOptions?.callbacks?.onBotStoppedSpeaking]);

  const onConnected = useCallback(() => {
    setIsConnected(true);
    clientOptions?.callbacks?.onConnected?.();
  }, [clientOptions?.callbacks?.onConnected]);

  const onDisconnected = useCallback(() => {
    setIsConnected(false);
    clientOptions?.callbacks?.onDisconnected?.();
  }, [clientOptions?.callbacks?.onDisconnected]);

  const callbacks = useMemo(() => ({
    ...clientOptions?.callbacks,
    onParticipantJoined,
    onTrackStarted,
    onError,
    onBotReady,
    onUserStartedSpeaking,
    onUserStoppedSpeaking,
    onBotStartedSpeaking,
    onBotStoppedSpeaking,
    onDisconnected,
    onConnected,
  }), [
    clientOptions?.callbacks, 
    onParticipantJoined, 
    onTrackStarted, 
    onError, 
    onBotReady, 
    onUserStartedSpeaking, 
    onUserStoppedSpeaking, 
    onBotStartedSpeaking, 
    onBotStoppedSpeaking,
    onDisconnected,
    onConnected,
  ]);

  const clientConfig = useMemo(() => ({
    enableMic: !noUserAudio,
    ...clientOptions,
    callbacks,
  }), [noUserAudio, clientOptions, callbacks]);

  useEffect(
    function initClient() {
      if (typeof window === "undefined") return;

      if (!connectParams) {
        console.error("connectParams is required");
        return;
      }

      let transport: SmallWebRTCTransport;
      try {
        transport = new SmallWebRTCTransport(
          connectParams as SmallWebRTCTransportConstructorOptions
        );
      } catch (error) {
        console.error("Failed to create transport:", error);
        return;
      }

      const finalConfig = {
        ...clientConfig,
        transport: (clientConfig?.transport as Transport) ?? transport,
      };

      const pcClient = new PipecatClient(finalConfig);

      pcClient.initDevices().catch((error) => {
        console.error("Failed to initialize devices:", error);
      });
      
      setClient(pcClient);
      setIsClientReady(true);

      return () => {
        /**
         * Disconnect client when component unmounts or options change.
         */
        pcClient.disconnect().catch((error) => {
          console.error("Failed to disconnect client:", error);
        });
        setClient(null);
        setIsClientReady(false);
      };
    },
    [clientConfig, connectParams, transportType]
  );

  useEffect(
    function updateSmallWebRTCCodecs() {
      if (!client || transportType !== "smallwebrtc") return;
      
      const transport = client.transport as SmallWebRTCTransport;
      if (audioCodec && transport.setAudioCodec) {
        transport.setAudioCodec(audioCodec);
      }
    },
    [audioCodec, client, transportType]
  );

  const handleConnect = useCallback(async (): Promise<void> => {
    if (!client) return;
    
    try {
      await client.connect();
      
      if (systemPrompt) {
        client.appendToContext({
          role: "assistant",
          content: systemPrompt,
          // run_immediately: true
        });
      }
    } catch (error) {
      console.error("Connection failed:", error);
      try {
        await client.disconnect();
      } catch (disconnectError) {
        console.error("Failed to disconnect after connection error:", disconnectError);
      }
    }
  }, [client, systemPrompt]);

  const handleDisconnect = useCallback(async (): Promise<void> => {
    if (!client) return;
    
    try {
      await client.disconnect();
    } catch (error) {
      console.error("Disconnect failed:", error);
    }
  }, [client]);

  return {
    client,
    isConnected,
    isClientReady,
    participantId,
    handleConnect,
    handleDisconnect,
  };
};