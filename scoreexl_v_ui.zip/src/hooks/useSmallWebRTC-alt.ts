import { useEffect, useState, useCallback } from "react";
import {
  type ConnectionEndpoint,
  PipecatClient,
  type PipecatClientOptions,
  type TransportConnectionParams,
} from "@pipecat-ai/client-js";
import { SmallWebRTCTransport } from "@pipecat-ai/small-webrtc-transport";

export interface SmallWebRTCOptions {
  audioCodec?: string;
  clientOptions?: Partial<PipecatClientOptions>;
  connectParams?: TransportConnectionParams | ConnectionEndpoint;
  enableMic?: boolean;
  onParticipantJoined?: (participant: any) => void;
  onTrackStarted?: (track: any, participant: any) => void;
  onConnected?: () => void;
  onDisconnected?: () => void;
}

export interface SmallWebRTCState {
  client: PipecatClient | null;
  transport: SmallWebRTCTransport | null;
  isClientReady: boolean;
  isConnected: boolean;
  isBotReady: boolean;
  participantId: string;
  error: string | null;
  remoteAudioTrack: MediaStreamTrack | null;
}

export interface SmallWebRTCActions {
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  setAudioCodec: (codec: string) => void;
  initDevices: () => Promise<void>;
}

const defaultOptions: Partial<SmallWebRTCOptions> = {
  audioCodec: "default",
  enableMic: true,
  clientOptions: {},
};

export const useSmallWebRTC = (
  options: SmallWebRTCOptions = {}
): SmallWebRTCState & SmallWebRTCActions => {
  const config = { ...defaultOptions, ...options };

  const [client, setClient] = useState<PipecatClient | null>(null);
  const [transport, setTransport] = useState<SmallWebRTCTransport | null>(null);
  const [isClientReady, setIsClientReady] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [isBotReady, setIsBotReady] = useState(false);
  const [participantId, setParticipantId] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [remoteAudioTrack, setRemoteAudioTrack] =
    useState<MediaStreamTrack | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const smallWebRTCTransport = new SmallWebRTCTransport({
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
    });

    if (config.audioCodec && config.audioCodec !== "default") {
      smallWebRTCTransport.setAudioCodec(config.audioCodec);
    } else {
      smallWebRTCTransport.setAudioCodec("default");
    }

    const pipecatClient = new PipecatClient({
      enableCam: false,
      enableMic: config.enableMic,
      ...config.clientOptions,
      transport: smallWebRTCTransport,
      callbacks: {
        onParticipantJoined: (participant) => {
          setParticipantId(participant.id || "");
          config.onParticipantJoined?.(participant);
        },
        onTrackStarted(track, participant) {
          console.log("Hook onTrackStarted:", { track, participant });
          if (participant?.id && participant.local) {
            setParticipantId(participant.id);
          }
          config.onTrackStarted?.(track, participant);
          config.clientOptions?.callbacks?.onTrackStarted?.(track, participant);
        },
        onTransportStateChanged: (state) => {
          console.log("Transport state changed:", state);
          config.clientOptions?.callbacks?.onTransportStateChanged?.(state);
        },
        onConnected: () => {
          setIsConnected(true);
          setError(null);
          config.onConnected?.();
        },
        onDisconnected: () => {
          setIsConnected(false);
          setIsBotReady(false);
          setRemoteAudioTrack(null);
          setError(null);
          config.onDisconnected?.();
        },
        onError: (message) => {
          setError(message.label || message.type || "An error occurred");
        },
        onBotReady: () => {
          console.log("Bot is ready!");
          setIsBotReady(true);
        },
        onUserStartedSpeaking: () => {
          console.log("User started speaking");
        },
        onUserStoppedSpeaking: () => {
          console.log("User stopped speaking");
        },
        onBotStartedSpeaking: () => {
          console.log("Bot started speaking");
        },
        onBotStoppedSpeaking: () => {
          console.log("Bot stopped speaking");
        },
        ...config.clientOptions?.callbacks,
      },
    });

    pipecatClient.initDevices();

    setTransport(smallWebRTCTransport);
    setClient(pipecatClient);
    setIsClientReady(true);

    return () => {
      pipecatClient.disconnect();
      setIsClientReady(false);
      setIsConnected(false);
      setParticipantId("");
      setError(null);
    };
  }, [config.enableMic, config.audioCodec]);

  const connect = useCallback(async () => {
    if (!client) {
      setError("Client not initialized");
      return;
    }

    try {
      setError(null);
      await client.connect(config.connectParams);
      console.log("Client connected", client);
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Connection failed";
      setError(errorMessage);
      await client.disconnect();
    }
  }, [client, config.connectParams]);

  const disconnect = useCallback(async () => {
    if (!client) return;

    try {
      await client.disconnect();
      setError(null);
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Disconnection failed";
      setError(errorMessage);
    }
  }, [client]);

  const setAudioCodec = useCallback(
    (codec: string) => {
      if (!transport) {
        setError("Transport not initialized");
        return;
      }

      try {
        transport.setAudioCodec(codec);
        setError(null);
      } catch (err) {
        const errorMessage =
          err instanceof Error ? err.message : "Failed to set audio codec";
        setError(errorMessage);
      }
    },
    [transport]
  );

  const initDevices = useCallback(async () => {
    if (!client) {
      setError("Client not initialized");
      return;
    }

    try {
      await client.initDevices();
      setError(null);
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to initialize devices";
      setError(errorMessage);
    }
  }, [client]);

  return {
    client,
    transport,
    isClientReady,
    isConnected,
    isBotReady,
    participantId,
    error,
    remoteAudioTrack,
    connect,
    disconnect,
    setAudioCodec,
    initDevices,
  };
};
